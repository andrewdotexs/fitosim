# Demo della tappa 3 fascia 2: chimica del substrato in azione

Questa è una demo didattica che mostra in azione tutte le funzionalità
del modello chimico introdotto nella tappa 3 della fascia 2 di fitosim.
Lo scopo è di vedere il modello "vivere" prima di costruire il `Garden`
orchestratore della tappa 4, e di darti uno script che potrai modificare
liberamente per esplorare scenari diversi sul tuo balcone.

## Cosa contiene

Un singolo file Python `tappa3_chemistry_demo.py` di circa 400 righe
che simula 30 giorni di vita di un vaso di basilico sul balcone
milanese, con eventi realistici alternati: piogge naturali, fertirri-
gazioni settimanali con BioBizz, qualche annaffiatura con acqua del
rubinetto, calibrazioni periodiche dal sensore ATO, e bagnature di
lavaggio reattive del giardiniere virtuale quando l'EC supera la
soglia agronomica.

L'esecuzione è deterministica (il random ha seed fissato a 42), quindi
ottieni sempre la stessa simulazione e puoi confrontare il tuo output
con quello documentato qui sotto.

## Come eseguirlo

Dalla root del progetto fitosim:

```bash
PYTHONPATH=src python examples/tappa3_chemistry_demo.py
```

L'output va a console: una tabella riga-per-giorno con stato del vaso
e eventi del giorno, seguita da una sintesi del periodo.

## Cosa mostra l'output

Ogni riga della tabella è un giorno della simulazione e contiene:

- **ET0**: evapotraspirazione di riferimento del giorno in mm.
- **θ**: umidità volumetrica del substrato (frazione tra 0 e theta_FC).
- **EC**: conducibilità elettrica del substrato in mS/cm. È una
  property derivata calcolata dal rapporto salt_mass / volume_acqua,
  quindi mostra spontaneamente il fenomeno della concentrazione per
  evapotraspirazione: nei giorni di sole asciugano il vaso e l'EC sale.
- **pH**: acidità del substrato in scala 0-14.
- **Ks**: coefficiente di stress IDRICO del modello FAO-56. Vale 1.0
  quando il vaso è ben idratato, scende verso 0 quando si avvicina
  al PWP. Il marker `k` accanto al valore segnala stress idrico
  (Ks < 0.95).
- **Kn**: coefficiente nutrizionale calcolato dallo stato chimico
  corrente. Vale 1.0 quando le condizioni chimiche sono ottimali,
  scende verso 0.30 in condizioni di stress chimico completo. Il
  marker `n` accanto al valore segnala stress chimico (Kn < 0.95).
- **Eventi**: simboli compatti per gli eventi della giornata:
  - `FERT` = fertirrigazione settimanale con BioBizz Bio-Grow
  - `TAP` = annaffiatura con acqua del rubinetto milanese
  - `LEACH` = bagnatura di lavaggio del giardiniere virtuale
  - `RAIN(N.Nmm)` = pioggia naturale di intensità N.N millimetri
  - `SENS` = calibrazione dal sensore ATO (settimanale)

I due marker di stress nelle colonne Ks e Kn sono la vera novità
diagnostica di questa demo: distinguono fenomeni fisiologici diversi
che richiedono interventi diversi.

**Stress idrico (`k` su Ks)**: il vaso sta asciugando e si avvicina
al PWP, la pianta fatica a estrarre acqua. Si risolve con
un'irrigazione di qualunque tipo (acqua pura, fertirrigazione, pioggia).

**Stress chimico (`n` su Kn)**: l'EC è fuori range (effetto osmotico
inverso) o il pH è fuori range (carenze nutrizionali). Si risolve
specificamente con un LAVAGGIO di acqua pura per ridurre i sali —
una fertirrigazione peggiorerebbe la situazione.

Vedere entrambi i marker simultaneamente (`k` e `n` nello stesso
giorno) è una situazione critica che richiede intervento immediato:
nei 30 giorni della demo capita 4 volte (giorni 3, 7, 12, 21).

## Il giardiniere virtuale e la regola di lavaggio

Per rendere la simulazione agronomicamente realistica, lo script
include un "giardiniere virtuale" che interviene reattivamente
quando l'EC supera una soglia derivata dal range della specie
(`ec_optimal_max + 0.5 mS/cm`, quindi 2.1 mS/cm per il basilico).
L'intervento è una bagnatura di lavaggio con acqua quasi pura
(EC=0.1 mS/cm, pH=7.0, volume 0.5 L) che provoca drenaggio
significativo e porta via i sali in eccesso.

Questa regola è semplificata: la `needs_leaching_irrigation()` del
file controlla solo l'EC. Nella tappa 4 (Garden orchestratore +
sistema di allerte) questa logica diventerà una "regola dichiarativa"
del sistema di allerte, che potrà notificare il giardiniere reale
quando intervenire invece di fare l'azione automaticamente.

## Cosa imparare dall'output di default

Ti elenco alcune osservazioni che emergono dalla simulazione standard
con seed=42 e ti aiutano a capire la dinamica del modello.

**Il giorno 1** parte con EC=0.98 mS/cm e Kn=1.00. La fertirrigazione
del giorno porta l'EC a 1.53, ben dentro il range (1.0-1.6), Kn=1.00.
**Già il giorno 2** la concentrazione per evapotraspirazione (3.83 mm
di ET) ha portato l'EC a 1.83 mS/cm, sopra il range, e Kn scende a
0.73 (stress moderato). Il giorno 3 l'EC è 2.20 mS/cm e Kn cade a
0.30 (stress completo), MA in più il vaso si è asciugato (Ks=0.87,
sotto comfort idrico). **Vedi entrambi gli stress contemporaneamente.**

**Il giorno 4** scatta il primo lavaggio reattivo (l'EC è sopra 2.1
mS/cm). L'acqua quasi pura del lavaggio provoca drenaggio e porta
via i sali: EC scende drasticamente a 1.24 mS/cm, ben dentro il range.
Sia Ks che Kn tornano a 1.00. Il vaso è "resettato".

**Il giorno 7** vede EC a 2.34 con Ks=0.60 e Kn=0.30: stress critico
combinato. Il giorno 8 c'è la fertirrigazione settimanale + pioggia
abbondante (17.7 mm) che insieme producono drenaggio significativo.

**Il giorno 9** la situazione è ancora difficile (Kn=0.30) e il
**giorno 10** scatta un secondo lavaggio. Il pattern si ripete con
**lavaggi reattivi** ai giorni 4, 10, 17, 19, 23, 30: sei interventi
in totale del giardiniere virtuale.

**Il bilancio finale** è radicalmente diverso dalla versione senza
giardiniere virtuale: bilancio netto +1.09 meq invece di +7.82 meq.
I lavaggi reattivi hanno compensato l'eccesso di sali dalle
fertirrigazioni, lasciando il vaso in una situazione chimica
equilibrata (EC finale 1.70 mS/cm, vicino al range ottimale; pH
finale 6.45, perfettamente nel range).

## Come modificare lo script per esplorare scenari diversi

Le costanti in cima al file sono il punto di intervento principale.

**Cambiare il seed**: modifica `RANDOM_SEED = 42` per esplorare
altre sequenze di piogge.

**Cambiare la durata**: `SIMULATION_DAYS = 30` può essere portato a
60 o 90 per simulare l'intera stagione vegetativa estiva.

**Cambiare la specie**: nella funzione `build_milan_basil_pot`
modifica i range `ec_optimal_min/max_mscm` e `ph_optimal_min/max`
per simulare specie diverse. La regola di lavaggio si adatta
automaticamente al nuovo range perché la soglia è
`ec_optimal_max + 0.5`.

**Cambiare l'esposizione alla pioggia**: porta `rainfall_exposure`
a 1.0 (vaso completamente scoperto) e poi a 0.0 (vaso totalmente
al riparo) per vedere come cambia il bilancio salino. Con esposizione
0.0 vedrai molti più eventi di lavaggio perché niente pioggia
contribuisce alla lisciviazione naturale.

**Disattivare il giardiniere virtuale**: nella funzione
`needs_leaching_irrigation` cambia il return a sempre `False`. Vedrai
la versione "senza intervento del giardiniere" con la salinizzazione
progressiva (+7.82 meq di bilancio netto) — la versione originale
prima di questo miglioramento.

**Cambiare la soglia di lavaggio**: modifica la formula della soglia
in `needs_leaching_irrigation` (per esempio `+ 0.3` invece che `+ 0.5`)
per vedere come cambia la frequenza dei lavaggi e il bilancio finale.
Una soglia più stretta produce più lavaggi e un bilancio più
equilibrato; una soglia più larga lascia il vaso accumulare più sali.

**Cambiare il dosaggio delle fertirrigazioni**: nella sezione del
loop principale dove c'è `fert_ec_mscm = 2.0` puoi sperimentare
con dosaggi più alti (3.0 mS/cm) o più bassi (1.0 mS/cm) e vedere
come cambia la frequenza dei lavaggi compensativi.

## Cosa cercare quando avrai dati reali

Quando il tuo gateway ESP32 sarà operativo e raccoglierai dati reali
dal tuo sensore ATO, le cose da osservare sono:

1. La **discrepanza media** sull'EC e sul pH dopo 1-2 settimane di
   dati. Un valore stabile e sistematico (sempre +0.1 mS/cm, sempre
   -0.1 di pH) indica un bias del modello da correggere; un valore
   che oscilla intorno allo zero indica solo rumore.

2. La **frequenza degli eventi di stress**: confronta i giorni in cui
   il modello dichiara stress (Ks<0.95 o Kn<0.95) con la salute reale
   della pianta osservata. Se il modello segnala stress quando la
   pianta sta benissimo, vuol dire che i parametri sono troppo stretti
   per la cultivar che hai e li dovremo allargare.

3. Il **bilancio netto dei sali** a fine mese, confrontato con quello
   simulato. Se il vaso reale si saliniza più del previsto, vuol dire
   che il modello sottostima il drenaggio salino o sovrastima
   l'efficacia delle piogge.

Tutti questi dati sono il materiale grezzo della futura fascia 3 di
calibrazione, che trasformerà fitosim da "libreria genericamente
plausibile" a "libreria calibrata per il TUO balcone milanese".
